import React, { Component } from 'react';
import './../styles/style.css';
import Modal from 'react-awesome-modal';
export default class ItemContainer extends Component {
    state = {
        visible: false
    }
    openModal = () => { this.setState({ visible: true }) }
    closeModal = () => { this.setState({ visible: false }) }
    styles = {
        margin: "21px"
    }
    closeStyle = {
        margin: "-10px",
        float: "right"
    }
    render() {
        return (
            <>
                <div className="divClass">
                    <img src={this.props.data.imageurl}></img>
                    <div>
                        <b>{this.props.data.name}</b>
                        <br />
                    </div>
                    {/* <div>
                        Author: {this.props.data.author}
                    </div>
                    <div>
                        Book's Count: {this.props.data.count}
                    </div>
                    <div>
                        Publish Year: {this.props.data.year}
                    </div>
                    <div>
                        ISBN: {this.props.data.isbn}
                    </div> */}
                    <button type="button" onClick={this.openModal}>info</button>
                    <button type="button">edit</button>
                    <Modal
                        visible={this.state.visible}
                        width="400"
                        height="400"
                        effect="fadeInUp"
                        onClickAway={() => this.closeModal()}>
                        <div style={this.styles}>
                            <div style={this.closeStyle}>
                                <a href="#" onClick={() => this.closeModal()}>Close</a>
                            </div>
                            <div style={this.styles}>
                                <b>{this.props.data.name}</b>
                                <br />
                            </div>
                            <div style={this.styles}>
                                Description: {this.props.data.description}
                            </div>
                            <div style={this.styles}>
                                Author: {this.props.data.author}
                            </div>
                            <div style={this.styles}>
                                Book's Count: {this.props.data.count}
                            </div>
                            <div style={this.styles}>
                                Publish Year: {this.props.data.year}
                            </div>
                            <div style={this.styles}>
                                ISBN: {this.props.data.isbn}
                            </div>

                        </div>
                    </Modal>

                </div >

            </>
        );
    }
}