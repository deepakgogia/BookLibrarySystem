import React, { Component } from 'react';
export class BookAdd extends Component {
    state = {
        name: '',
        year: '',
        count: 0,
        isbn: '',
        author: '',
        imagerurl: '',
        description: ''

    }
    render() {
        const { name, year, count, description, isbn, author, imagerurl } = this.state;
        return (
            <>
                <form >
                    <h1>Add New Book</h1>
                    <div>
                        <label htmlFor="name">Book's Name</label>
                        <input id="name" value={name} onChange={e => this.txtChangeEventHandler(e)} />
                    </div>
                    <div>
                        <label htmlFor="description">Book's Description</label>
                        <input id="description" value={description} onChange={e => this.txtChangeEventHandler(e)} />
                    </div>
                    <div>
                        <label htmlFor="author">Author's Name</label>
                        <input id="author" value={author} onChange={e => this.txtChangeEventHandler(e)} />
                    </div>
                    <div>
                        <label htmlFor="year">Published Year</label>
                        <input id="year" value={year} onChange={e => this.txtChangeEventHandler(e)} />
                    </div>
                    <div>
                        <label htmlFor="isbn">ISBN No</label>
                        <input id="isbn" onChange={e => this.txtChangeEventHandler(e)} />
                    </div>
                    <div>
                        <label htmlFor="count">Book's Count</label>
                        <input id="count" onChange={e => this.txtChangeEventHandler(e)} />
                    </div>
                    <div>
                        <button>Submit</button>
                        <button type="reset">Cancel</button>
                    </div>
                </form>
            </>
        );
    }
}