import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import getAllData from './../services/userservice';
import ItemContainer from './ItemContainer';
import './../styles/style.css';

export class Home extends Component {
    state = {
        totalData: [],
        searchData: '',
        showData: []
    }
    async componentDidMount() {
        var data = await getAllData();
        this.setState({ totalData: data, showData: data })
    }
    txtChangeHandler = (e) => {
        const newState = { ...this.state };
        newState.searchData = e.target.value;
        newState.showData = this.state.totalData.filter(z => z.name.includes(newState.searchData));
        this.setState(newState);
    }
    btnAddBookHandler = () => {
        this.props.history.push("/addnewbook");
    }
    render() {
        const { showData, searchData } = this.state;
        return (
            <>
                <div className="divMainHeader">
                    <div className="divTitle">
                        <h1>Book Library System</h1>
                    </div>
                    <div className="divAddBook">
                        <button onClick={this.btnAddBookHandler}>Add Book</button>
                    </div>
                </div>
                {/* <div> <Link to="/addnewbook">Add Book</Link> </div> */}
                <div className="inputSearch">
                    <input placeholder="Search By Book Name" value={searchData} onChange={this.txtChangeHandler} />
                    <span>{showData.length > 0 ? "Total Count: " + showData.length : "No Record Found"}</span>
                </div>
                <div className="divMainContainer">
                    {showData && showData.map(z => {
                        return <ItemContainer key={z.isbn} data={z} />
                    })}
                </div>
            </>
        );
    }
}